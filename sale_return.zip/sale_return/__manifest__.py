# -*- coding: utf-8 -*-
{
    'name': 'Sale Returned',
    "version" : "13",
    'author': 'Newsys',
    'category': 'Newsys',
    'website': '',
    'depends': ['sale','stock','product'],
    'data': [ 'security/ir.model.access.csv',
             'views/sale_sequence.xml',
            # 'security/security.xml',
            'wizard/wizard_sale_return_view.xml',
            'wizard/wizard_sale_return_product_view.xml',
            'views/invoicing_view.xml',
            'views/sale_return_view.xml',
            'report/report_py3o.xml',
            'report/report_view.xml',
            'report/report_salereturn.xml',
            #  'report/report_view.xml'
        
        
        ],
    'installable': True,
    'auto_install': False,
}
