# -*- coding: utf-8 -*-
from . import sale_return
from . import invoicing
from . import stock
from . import ir_sequence_inherit
