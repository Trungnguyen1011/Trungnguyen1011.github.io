# -*- coding: utf-8 -*-
from itertools import groupby
from operator import truediv


from odoo import api, fields, models, _
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT
from odoo.tools.translate import _
from odoo.tools.float_utils import float_is_zero, float_compare
from odoo.exceptions import UserError, AccessError


class SaleReturnInvoice(models.TransientModel):
    _name = "sale.return.invoice"
    
    group_by_taxes = fields.Boolean(string="Group by Taxes", default = False)
    
    def action_view_invoice(self):
        context = self._context
        if context.get('active_model') == 'sale.return' and context.get('active_ids'):
            sale = self.env['sale.return'].browse(context['active_ids'])[0]
            invoice_ids = sale.mapped('invoice_ids')
            
            imd = self.env['ir.model.data']
            action = imd.xmlid_to_object('account.action_move_out_refund_type')
            list_view_id = imd.xmlid_to_res_id('account.move_tree')
            form_view_id = imd.xmlid_to_res_id('account.move_form')
            invoice_count = len(invoice_ids)
            if not len(invoice_ids):
                self.action_create_invoice()
                invoice_count += 1
                invoice_ids = sale.mapped('invoice_ids')
                
            
            result = {
                'name': action.name,
                'help': action.help,
                'type': action.type,
                'views': [[list_view_id, 'tree'], [form_view_id, 'form'], [False, 'graph'], [False, 'kanban'], [False, 'calendar'], [False, 'pivot']],
                'target': action.target,
                'context': action.context,
                'res_model': action.res_model,
            }
            if invoice_count > 1:
                result['domain'] = "[('id','in',%s)]" % invoice_ids.ids
            elif invoice_count == 1:
                result['views'] = [(form_view_id, 'form')]
                result['res_id'] = invoice_ids.ids[0]
            else:
                result = {'type': 'ir.actions.act_window_close'}
            return result
    
    
    def _prepare_invoice(self, sale):
        self.ensure_one()
        if not sale:
            return
        journal = self.env['account.move'].with_context(default_type='out_refund')._get_default_journal()

        invoice_vals = {
            'ref':sale.client_order_ref or '',
            'invoice_origin': sale.name,
            'type': 'out_refund',
            'journal_id': journal.id,
            'partner_id': sale.partner_id.id,
            'currency_id': sale.currency_id.id,
            'narration': sale.note,
            'invoice_payment_term_id': sale.payment_term_id.id,
            'fiscal_position_id': sale.fiscal_position_id.id or sale.partner_id.property_account_position_id.id,
            'company_id': sale.company_id.id,
            'user_id': sale.user_id and sale.user_id.id,
            'team_id': sale.team_id.id,
            'invoice_line_ids': [],
            }
        return invoice_vals
    
    def _prepare_invoice_line(self, sale_line):
        if not sale_line:
            return
        
        account = sale_line.product_id.categ_id.property_account_expense_categ_id or False
        if not account:
            raise UserError(_('Please define income account for this product: "%s" (id:%d) - or for its category: "%s".') % \
                            (sale_line.product_id.name, sale_line.product_id.id, sale_line.product_id.categ_id.name))
        fpos = sale_line.order_id.fiscal_position_id or sale_line.order_id.partner_id.property_account_position_id
        if fpos:
            account = fpos.map_account(account)
            
        res = {
            'display_type': sale_line.display_type,
            'name': sale_line.name,'sequence': sale_line.sequence,
            'ref': sale_line.order_id.name,
            'account_id': account.id,
            'price_unit': sale_line.price_unit,
            'discount':sale_line.discount,
            'quantity': sale_line.product_uom_qty,
            'product_uom_id': sale_line.product_uom.id,
            'product_id': sale_line.product_id.id or False,
            'tax_ids': [(6, 0, sale_line.tax_id.ids)],
            'sale_return_line_ids': [(6, 0, [sale_line.id])],
            'analytic_account_id': sale_line.order_id.analytic_account_id.id,
            'analytic_tag_ids': [(6, 0, sale_line.analytic_tag_ids.ids)],
            }
        return res
    
    
    
    def action_create_invoice(self,grouped=False, final=False):
        context = self._context
        if context.get('active_model') == 'sale.return' and context.get('active_ids'):
            sale = self.env['sale.return'].browse(context['active_ids'])[0]
        else: 
            return
            
        if not self.env['account.move'].check_access_rights('create', False):
            try:
                sale.check_access_rights('write')
                sale.check_access_rule('write')
            except AccessError:
                return self.env['account.move']
        invoice_vals_list = []
        invoice_vals = self._prepare_invoice(sale)
        invoiceable_lines = self._get_invoiceable_lines(sale)
        line_data = []
        for sale_line in invoiceable_lines:
            vals = self._prepare_invoice_line(sale_line)
            # vals.update({'move_id': invoice_id.id})
            line_data.append((0, 0, vals))
        invoice_vals['invoice_line_ids'] = line_data
            # self.env['account.move.line'].create(vals)
        invoice_vals_list.append(invoice_vals)   
        # invoice_id.compute_taxes()
        # invoice_id.signal_workflow('invoice_open')
        if not invoice_vals_list:
            raise UserError(_(
                'There is no invoiceable line. If a product has a Delivered quantities invoicing policy, please make sure that a quantity has been delivered.'))
            # 2) Manage 'grouped' parameter: group by (partner_id, currency_id).
        if not grouped:
            new_invoice_vals_list = []
            invoice_grouping_keys = ['company_id', 'partner_id', 'currency_id']
            invoice_vals_list = sorted(invoice_vals_list, key=lambda x: [x.get(grouping_key) for grouping_key in invoice_grouping_keys])
            for grouping_keys, invoices in groupby(invoice_vals_list, key=lambda x: [x.get(grouping_key) for grouping_key in invoice_grouping_keys]):
                origins = set()
                refs = set()
                ref_invoice_vals = None
                for invoice_vals in invoices:
                    if not ref_invoice_vals:
                        ref_invoice_vals = invoice_vals
                    else:
                        ref_invoice_vals['invoice_line_ids'] += invoice_vals['invoice_line_ids']
                    origins.add(invoice_vals['invoice_origin'])
                    refs.add(invoice_vals['ref'])
                ref_invoice_vals.update({
                    'ref': ', '.join(refs)[:2000],
                    'invoice_origin': ', '.join(origins)
                })
                new_invoice_vals_list.append(ref_invoice_vals)
            invoice_vals_list = new_invoice_vals_list

        if len(invoice_vals_list) < len(sale):
            SaleReturnLine = self.env['sale.return.line']
            for invoice in invoice_vals_list:
                sequence = 1
                for line in invoice['invoice_line_ids']:
                    line[2]['sequence'] = SaleReturnLine._get_invoice_line_sequence(new=sequence, old=line[2]['sequence'])
                    sequence += 1

        moves = self.env['account.move'].sudo().with_context(default_type='out_refund').create(invoice_vals_list)
        

        if final:
            moves.sudo().filtered(lambda m: m.amount_total < 0).action_switch_invoice_into_refund_credit_note()
        for move in moves:
            move.message_post_with_view('mail.message_origin_link',
                values={'self': move, 'origin': move.line_ids.mapped('sale_line_ids.order_id')},
                subtype_id=self.env.ref('mail.mt_note').id
            )
        return moves  
        
        
    def _get_invoiceable_lines(self,return_order, final=False):
        invoiceable_line_ids = []
        pending_section = None
        precision = self.env['decimal.precision'].precision_get('Product Unit of Measure')

        for line in return_order.order_line:
            if line.display_type == 'line_section':
                # Only invoice the section if one of its lines is invoiceable
                pending_section = line
                continue
            if line.display_type != 'line_note' and float_is_zero(line.qty_to_invoice, precision_digits=precision):
                continue
            if line.qty_to_invoice > 0 or (line.qty_to_invoice < 0 and final) or line.display_type == 'line_note':
                if pending_section:
                    invoiceable_line_ids.append(pending_section.id)
                    pending_section = None
                invoiceable_line_ids.append(line.id)

        return self.env['sale.return.line'].browse(invoiceable_line_ids)