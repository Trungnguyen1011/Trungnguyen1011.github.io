# -*- coding: utf-8 -*-
import time
from datetime import datetime
from odoo import SUPERUSER_ID
from odoo import api, fields, models, _
from odoo.tools import float_compare, DEFAULT_SERVER_DATETIME_FORMAT
from odoo.tools.misc import formatLang, get_lang
from odoo.exceptions import UserError
import base64, xlrd, unicodedata

class SaleReturn(models.Model):
    _name = "sale.return"
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'date_order desc, id desc'
    _description = "Returns Order"
    
    
    @api.depends('order_line.price_total')
    def _amount_all(self):
        for order in self:
            amount_untaxed = amount_tax = 0.0
            for line in order.order_line:
                amount_untaxed += line.price_subtotal
                amount_tax += line.price_tax
            if len(order.pricelist_id) != 0:
                order.update({
                    'amount_untaxed': order.pricelist_id.currency_id.round(amount_untaxed),
                    'amount_tax': order.pricelist_id.currency_id.round(amount_tax),
                    'amount_total': amount_untaxed + amount_tax,
                })

    
    @api.depends('order_line.move_ids.picking_id')
    def _compute_picking(self):
        for order in self:
            pickings = self.env['stock.picking']
            for line in order.order_line:
                # moves = line.move_ids.filtered(lambda r: r.state != 'cancel')
                pickings |= line.move_ids.mapped('picking_id')
            order.picking_ids = pickings
            order.picking_count = len(pickings)
    
    @api.depends('state', 'order_line.invoice_lines.move_id.state')
    def _get_invoiced(self):
        for order in self:
            invoices = self.env['account.move']
            for line in order.order_line:
                invoices |= line.invoice_lines.mapped('move_id')
            order.invoice_ids = invoices
            order.invoice_count = len(invoices)
            if order.state not in ('return', 'done'):
                order.invoice_status = 'no'
                continue
            precision = self.env['decimal.precision'].precision_get('Product Unit of Measure')
            if any(float_compare(line.qty_invoiced, line.product_uom_qty, precision_digits=precision) == -1 for line in order.order_line):
                order.invoice_status = 'to invoice'
            elif all(float_compare(line.qty_invoiced, line.product_uom_qty, precision_digits=precision) >= 0 for line in order.order_line):
                order.invoice_status = 'invoiced'
            else:
                order.invoice_status = 'no'
                
    READONLY_STATES = {
        'approve': [('readonly', True)],
        'return': [('readonly', True)],
        'done': [('readonly', True)],
        'cancel': [('readonly', True)],
    }
       
    @api.model
    def _default_note(self):
        return self.env.user.company_id.website
    
    @api.onchange('fiscal_position_id')
    def _compute_tax_id(self):
        for order in self:
            order.order_line._compute_tax_id()
            
    
    @api.depends('state', 'order_line.product_uom_qty','order_line.qty_received')
    def _total_qty(self):
        for order in self:
            order.total_qty = sum(order.order_line.mapped('product_uom_qty')) or 0
            order.total_qty_receive = sum(order.order_line.mapped('qty_received')) or 0

    
    @api.depends('order_line.qty_received', 'order_line.price_unit')
    def _compute_amount_total_receive(self):
        for order in self:
            amount_total_receive = 0.0
            for line in order.order_line:
                amount_total_receive += order.pricelist_id.currency_id.round(line.qty_received * line.price_unit)
            order.amount_total_receive = amount_total_receive
            
    @api.model
    def _default_picking_type(self):
        type_obj = self.env['stock.picking.type']
        types = type_obj.search([('code', '=', 'return_customer')],limit=1)
        return types[:1]

            
    @api.depends('state', 'order_line.move_ids.picking_id.state')
    def _get_warehouse_status(self):
        for order in self:
            warehouse_status = 'waiting'
            line_warehouse_status = [picking.state for picking in order.picking_ids]
            if line_warehouse_status:
                if all(state == 'done' for state in line_warehouse_status):
                    warehouse_status = 'done'
                elif all(state == 'cancel' for state in line_warehouse_status):
                    warehouse_status = 'cancel'
                elif any(state == 'done' for state in line_warehouse_status):
                    warehouse_status = 'partially'

            order.warehouse_status = warehouse_status
            
    name = fields.Char(string='Order Reference', required=True, copy=False, readonly=False, index=True, default='New')
    origin = fields.Char(string='Source Document', help="Reference of the document that generated this sales order request.", copy=False)
    
    partner_id = fields.Many2one('res.partner', string='Customer', states=READONLY_STATES, required=True, change_default=True, index=True, track_visibility='always')
    client_order_ref = fields.Char(string='Customer Reference', copy=False)
    
    invoice_count = fields.Integer(string='# of Invoices', compute='_get_invoiced', readonly=True, store=True)
    invoice_ids = fields.Many2many("account.move", string='Invoices', compute="_get_invoiced", readonly=True, copy=False, store=True)
    invoice_status = fields.Selection([
        ('upselling', 'Upselling Opportunity'),
        ('invoiced', 'Fully Invoiced'),
        ('to invoice', 'To Invoice'),
        ('no', 'Nothing to Invoice')
        ], string='Invoice Status', compute='_get_invoiced', store=True, readonly=True, default='no')

    state = fields.Selection([
        ('draft', 'Draft'),
        ('sent', 'RFR Sent'),
        ('approve', 'Approved'),
        ('return','Returns Order'),
        ('done', 'Done'),
        ('cancel', 'Cancelled')
        ], string='Status', readonly=True, copy=False, index=True, track_visibility='onchange', default='draft')
    
    validity_date = fields.Datetime(string='Expiration Date', states=READONLY_STATES, required=False, select=True, default=fields.Datetime.now())
    date_order = fields.Datetime(string='Date Reverse', required=True ,index=True, states=READONLY_STATES, copy=False, default=fields.Date.context_today)

    pricelist_id = fields.Many2one('product.pricelist', string='Pricelist', required=True, states=READONLY_STATES, help="Pricelist for current sales order.")
    currency_id = fields.Many2one("res.currency", related='pricelist_id.currency_id', string="Currency", required=True, default=lambda self: self.env.user.company_id.currency_id, states=READONLY_STATES)
    currency_rate = fields.Float(string='Currency Rate', default=1.0, copy=False, required=True, states=READONLY_STATES,)
    project_id = fields.Many2one('account.analytic.account', 'Analytic Account', states=READONLY_STATES, help="The analytic account related to a sales order.", copy=False)

    order_line = fields.One2many('sale.return.line', 'order_id', string='Order Lines', states=READONLY_STATES, copy=True)

    note = fields.Text('Terms and conditions', default=_default_note)

    amount_untaxed = fields.Monetary(string='Untaxed Amount', store=True, readonly=True, compute='_amount_all', track_visibility='always')
    amount_tax = fields.Monetary(string='Taxes', store=True, readonly=True, compute='_amount_all', track_visibility='always')
    amount_total = fields.Monetary(string='Total', store=True, readonly=True, compute='_amount_all', track_visibility='always')

    payment_term_id = fields.Many2one('account.payment.term', string='Payment Term', oldname='payment_term')
    fiscal_position_id = fields.Many2one('account.fiscal.position', oldname='fiscal_position', string='Fiscal Position')
    company_id = fields.Many2one('res.company', 'Company', required=True, select=1, states=READONLY_STATES, default=lambda self: self.env.user.company_id.id)
    
    picking_count = fields.Integer(compute='_compute_picking', string='Receptions', default=0)
    picking_ids = fields.Many2many('stock.picking', compute='_compute_picking', string='Receptions', copy=False)
    
#     currency_currency_id = fields.Many2one(related='company_id.currency_id', store=True, string='Currency Company', readonly=True)
#     currency_amount_tax = fields.Float(compute='_currency_amount_all',digits=(16,0) , string='Amount Tax',store=True)
#     currency_amount_untaxed = fields.Float(compute='_currency_amount_all',digits=(16,0) , string = 'Untaxed Amount',store=True)
#     currency_amount_total = fields.Float(compute='_currency_amount_all',digits=(16,0) , string='Amount Total',store=True)
#     currency_order_line = fields.One2many('sale.return.line', 'order_id', string='Order Lines', readonly=True,copy=False)
    
    sale_order_id = fields.Many2one(related="order_line.sale_line_id.order_id", string='Sale Order', readonly=True, copy=True, store=True)
    
    picking_type_id = fields.Many2one('stock.picking.type', 'Picking Type', domain=[('code','=','return_customer')], 
            index=True, states=READONLY_STATES,required=True, default=_default_picking_type)
    
    analytic_account_id = fields.Many2one(
        'account.analytic.account', 'Analytic Account',
        readonly=True, copy=False, check_company=True,  # Unrequired company
        states={'draft': [('readonly', False)], 'sent': [('readonly', False)]},
        domain="['|', ('company_id', '=', False), ('company_id', '=', company_id)]",
        help="The analytic account related to a sales order.")
    
    
    
    def _get_warehouse_id(self):
        user_id = self.env.user
        for rec in self:
            count = 0
            array_wid = []
            if user_id:
                for wh in self.sale_order_id.warehouse_id:
                    array_wid.append(wh['id'])                
                    count = count + 1       
                if count <1:
                    return True
                if count == 1:              
                    return [('id','=',int(array_wid[0]))]            
                else:              
                    return [('id','in',tuple(array_wid))]
    
    
    def _get_default_warehouse_id(self):
        company = self.env.company.id
        warehouse_ids = self.env['stock.warehouse'].search([('company_id', '=', company)], limit=1)
        return warehouse_ids

    
    warehouse_id = fields.Many2one('stock.warehouse', string='Warehouse',required=True,
                    domain = _get_warehouse_id,default=_get_default_warehouse_id ,states=READONLY_STATES)
    
    
    warehouse_status = fields.Selection([('waiting','Waiting'),
                                        ('partially','Partially'),
                                        ('done','Done'),
                                        ('cancel','Cancel')], string='Warehouse Status',compute='_get_warehouse_status', readonly=True, default='waiting',store=True,)
    create_uid = fields.Many2one('res.users', 'Responsible')
    date_approve = fields.Date('Approval Date', readonly=1, select=True, copy=False)
    
    total_qty = fields.Float(compute='_total_qty',digits=(16,2) , string = 'Total Qty', store=True)
    total_qty_receive = fields.Float(compute='_total_qty',digits=(16,2) , string = 'Total Qty Receive', store=True)
    amount_total_receive = fields.Monetary(string='Total Receive', store=True, readonly=True, compute='_compute_amount_total_receive', track_visibility='always')

    team_id = fields.Many2one('crm.team', 'Sales Team', change_default=True, oldname='section_id')
    user_id = fields.Many2one('res.users', 'Responsible', required=True, readonly=True ,states={'draft':[('readonly',False)]}, track_visibility="onchange", copy=False,default=lambda self: self.env.user)
        
    user_confirm = fields.Many2one('res.users', string='User Confirm', readonly=True)
    user_approve = fields.Many2one('res.users', string='User Approve', readonly=True)
    
    file = fields.Binary('File', help='Choose file Excel', copy=False, readonly=True, states={'draft':[('readonly',False)],'sent':[('readonly',False)]})
    file_name =  fields.Char('Filename', size=100, readonly=True, copy=False, default='SO Lines.xls')
    
    failure = fields.Integer('Error(s)', default=0, copy=False)
    warning_mess = fields.Text('Message', copy=False)
    
    # line_error_ids = fields.One2many('errror.import','sale_return_id',string='Line Error', readonly=True, states={'draft':[('readonly',False)]}, copy=False)
    
    _sql_constraints = [
        ('name_so_return_unique', 'unique(name)', 'Name of sale return order must be unique!'),
    ]
    
    
    def button_loading(self):
        return_obj = self.env['sale.return.line']
        vals = {}
        for this in self:
            if this.order_line:
                self.env.cr.execute("DELETE FROM sale_return_line WHERE id in (SELECT id FROM sale_return_line WHERE order_id = %s)"%(this.id))
            if this.order_id:
                for i in this.order_id.order_line:
                    vals = {'order_id': this.id or False, 'name': i.name or '',
                            'product_id': i.product_id.id or False,'product_uom_qty': i.product_uom_qty or 0.0,
                            'product_uom': i.product_uom.id or False,'price_unit': i.price_unit or 0.0,'tax_id': [(6, 0, i.tax_id.ids)] or False} 
                    new_id = return_obj.create(vals)
        return True
    
    
    def button_dummy(self):
        return True
    
    @api.onchange('warehouse_id')
    def onchange_warehouse_id(self):
        if not self.warehouse_id:
            return
        self.picking_type_id = self.warehouse_id.pick_type_id.id
    
    @api.onchange('partner_id')
    def onchange_partner_id(self):
        if not self.partner_id:
            self.update({
                'fiscal_position_id': False,
                'payment_term_id': False,
                'currency_id': False,
                    })
            return
        
        addr = self.partner_id.address_get(['delivery', 'invoice'])
        values = {
            'pricelist_id': self.partner_id.property_product_pricelist and self.partner_id.property_product_pricelist.id or False,
            'fiscal_position_id': self.env['account.fiscal.position'].get_fiscal_position(self.partner_id.id),
            'payment_term_id': self.partner_id.property_supplier_payment_term_id.id,
            'currency_id': self.partner_id.property_purchase_currency_id.id or self.env.user.company_id.currency_id.id,
                }
        if self.partner_id.team_id:
            values['team_id'] = self.partner_id.team_id.id
        self.update(values)
        
    @api.model
    def create(self, vals):
        if vals.get('name', 'New') == 'New':
            vals['name'] = self.env['ir.sequence'].next_by_code('sale.return') or 'New'

        if any(f not in vals for f in ['partner_invoice_id', 'partner_shipping_id', 'pricelist_id']):
            partner = self.env['res.partner'].browse(vals.get('partner_id'))
            vals['pricelist_id'] = vals.setdefault('pricelist_id', partner.property_product_pricelist and partner.property_product_pricelist.id)
        return super(SaleReturn, self).create(vals)
    
    
    def unlink(self):
        for order in self:
            if order.state != 'draft':
                raise UserError(_('You can only delete draft return!'))
        return super(SaleReturn, self).unlink()
    
    
    def print_report(self):
        return {'type': 'ir.actions.report.xml','report_name':'report_sale_return'}
    
    
    def button_draft(self):
        for order in self:
            if order.state == 'done':
                order.write({'state': 'return'})
            else:
                order.write({'state': 'draft'})
        
    
    def action_cancel(self):
        for order in self:
            if any(order.picking_ids.filtered(lambda x: x.state != 'cancel')):
                raise UserError(_('Unable to cancel sale order reutrn %s.') % (order.name))
            order.picking_ids.write({'block_picking': True})
        self.write({'state': 'cancel'})
        
    
    def action_done(self):
        if self.warehouse_status != 'done' or self.invoice_status != 'invoiced':
            if self._context.get('show_raise',False):
                raise UserError(_('You can not set Completed Sales Refund.'))
            else:
                return 
        self.write({'state': 'done'})
        
    
    def button_confirm(self):
        self.write({'state': 'approve', 'user_confirm': self.env.uid})
    
    
    def button_approve(self):
        if self.state in ('draft,sent'):
            self.button_confirm()
        self.write({'state': 'return', 'date_approve': datetime.now().strftime(DEFAULT_SERVER_DATETIME_FORMAT), 'user_approve': self.env.uid})
        if not self._context.get('no_pick',False):
            self._create_picking()
        
    
    def button_onhand(self):
        imd = self.env['stock.quant']
        result = imd.action_view_quants()
        result['target'] = 'new'
        # result['context'] = {'group_by': ['product_id']}
        if self.warehouse_id and len(self.order_line):
            
            order_line = [x.id for x in self.order_line]
            if len(order_line) > 1:
                result['domain'] = ("""['&','&',('quantity','!=',0),('location_id','child_of',%s),('product_id','in',(%s))]""") % (self.warehouse_id.lot_stock_id.id,
                                                                       ','.join(map(str, [x.product_id.id for x in self.order_line])))
            else:
                result['domain'] = ("""['&','&',('quantity','!=',0),('location_id','child_of',%s),('product_id','=',(%s))]""") % (self.warehouse_id.lot_stock_id.id,
                                                                        ','.join(map(str, [x.product_id.id for x in self.order_line])))
        else:
            result = {'type': 'ir.actions.act_window_close'}                                                                        
        return result    
    
    
    @api.model
    def _prepare_picking(self):
        return {
            'partner_id': self.partner_id.id,
            'picking_type_id': self.picking_type_id.id or self.warehouse_id.pick_type_id.id,
            'partner_id': self.partner_id.id,
            'date': self.date_order,
            'scheduled_date': self.validity_date or datetime.utcnow(), 
            'origin': self.sale_order_id and _(self.sale_order_id.name) + _('/') + _(self.name) or self.name,
            'location_id': self.partner_id.property_stock_customer.id or self.picking_type_id.default_location_src_id.id or  False, 
            'location_dest_id': self.warehouse_id.lot_stock_id.id or False,
                }

    
    def _create_picking(self):
        for order in self:
            ptypes = order.order_line.mapped('product_id.type')
            if ('product' in ptypes) or ('consu' in ptypes):
                res = order._prepare_picking()
                picking = self.env['stock.picking'].create(res)
                moves = order.order_line.filtered(lambda r: r.product_id.type in ['product', 'consu'])._create_stock_moves(picking)
                move_ids = moves._action_confirm()
                moves = self.env['stock.move'].browse(move_ids).ids
                for move in moves:
                    move.force_assign()
        return True
    
    
    def action_view_picking(self):
        action = self.env.ref('stock.action_picking_tree_all')
        result = action.read()[0]
        pick_ids = sum([order.picking_ids.ids for order in self], [])
        if len(pick_ids) > 1:
            result['domain'] = "[('id','in',[" + ','.join(map(str, pick_ids)) + "])]"
        elif len(pick_ids) == 1:
            res = self.env.ref('stock.view_picking_form', False)
            result['views'] = [(res and res.id or False, 'form')]
            result['res_id'] = pick_ids and pick_ids[0] or False
        else:
            result = {'type': 'ir.actions.act_window_close'}
        return result
    
    
    def action_rfr_send(self):
        self.ensure_one()
        ir_model_data = self.env['ir.model.data']
        try:
            if self.env.context.get('send_rfr', False):
                template_id = ir_model_data.get_object_reference('general_sale_return', 'email_template_edi_salereturn')[1]
            else:
                template_id = ir_model_data.get_object_reference('general_sale_return', 'email_template_edi_salereturn_done')[1]
        except ValueError:
            template_id = False
        try:
            compose_form_id = ir_model_data.get_object_reference('mail', 'email_compose_message_wizard_form')[1]
        except ValueError:
            compose_form_id = False
        ctx = dict(self.env.context or {})
        ctx.update({
            'default_model': 'sale.return',
            'default_res_id': self.ids[0],
            'default_use_template': bool(template_id),
            'default_template_id': template_id,
            'default_composition_mode': 'comment',
        })
        return {
            'name': _('Compose Email'),
            'type': 'ir.actions.act_window',
            'view_mode': 'form',
            'res_model': 'mail.compose.message',
            'views': [(compose_form_id, 'form')],
            'view_id': compose_form_id,
            'target': 'new',
            'context': ctx,
        }
            
    
    def print_report_template(self):
        return {'type': 'ir.actions.report', 
                'report_name': 'sale_return.report_returnorder',
                'model' : 'sale.return',
                'report_type': 'qweb-pdf'
                }
    
    
    def print_report_error(self):
        return {'type': 'ir.actions.report', 'report_name': 'report_import_sale_return_error'}
    
    
    def button_warning_mess(self):
        if not self.warning_mess:
            return
        raise UserError(_(self.warning_mess))
    
    
    def import_file(self):
        flag = False
        success = failure = 0
        return_lines = []
        line_errror =[]
        warning = False
        for this in self:
            try:
                recordlist = base64.decodestring(this.file)
                excel = xlrd.open_workbook(file_contents = recordlist)
                sh = excel.sheet_by_index(0)
            except Exception:
                raise UserError(('Please select File'))
            if sh:
                self.env.cr.execute('''
                BEGIN;
                    DELETE FROM sale_return_line where order_id = %s;
                COMMIT;'''%(this.id,this.id))
                messenger = ''
                for row in range(sh.nrows):
                    error = False
                    mess = ''
                    if row > 3:
                        im_default_code = sh.cell(row,0).value or False
                        im_uom = sh.cell(row,1).value or False
                        im_qty = sh.cell(row,2).value or False
                        im_price_unit = sh.cell(row,3).value or 0.0

                        product = self.env['product.product']
                        productuom = self.env['product.uom']
                        relation =self.env['product.uom.relation']
                        
                        product_id = default_code = product_ean = uom_id = product_uom = product_name = False
                        qty = price_unit = 0
                        
                        if im_uom:
                            if isinstance(im_uom, unicodedata):
                                im_uom = im_uom.lstrip()
                                im_uom = im_uom.rstrip()
                                
                            if isinstance(im_uom, float):
                                im_uom = int(im_uom)
                                im_uom = str(im_uom)
                            
                            uom_ids = productuom.search([('name','=',im_uom)], limit=1)
                            if not uom_ids:
                                error = True
                                mess = _(' This UoM'+ _(im_uom) +' is not exist.')
                            else:
                                uom_id = uom_ids.id
                        
                        if not im_default_code:
                            error = True
                            mess = _(' This Item Code/ Barcode is not null.')
                        else:
                            if isinstance(im_default_code, unicodedata):
                                im_default_code = im_default_code.lstrip()
                                im_default_code = im_default_code.rstrip()
                                
                            if isinstance(im_default_code, float):
                                im_default_code = int(im_default_code)
                                im_default_code = str(im_default_code)
                            
                            product_ids = product.search([('default_code','=',im_default_code),('active','=',True)], limit=1) or []
                            if not len(product_ids):
                                relation_ids = relation.search([('barcode','=',im_default_code),('active','=',True)], limit=1) or []
                                if not len(relation_ids):
                                    error = True
                                    mess = _(' This Item Code/ Barcode '+ (im_default_code) +' is not exist or was unarchive.')
                                else:
                                    default_code = im_default_code
                                    product_ean = im_default_code
                                    product_id = relation_ids.product_product_id or relation_ids.product_id.product_variant_ids[0]
                                    if (uom_id and uom_id != relation_ids.uom_id.id) or not uom_id:
                                        uom_id = relation_ids.uom_id.id
                            else:   
                                default_code = im_default_code
                                product_ean = False
                                product_id = product_ids
                                if (uom_id and ((uom_id != product_ids.uom_id.id) or (uom_id != product_ids.uom_po_id.id))) or not uom_id:
                                    uom_id = product_ids.uom_po_id.id
                        
                        if not im_qty:
                            qty = 1
                        else:
                            if isinstance(im_qty, float):
                                if im_qty < 0:
                                    error = True
                                    mess = mess + _(' Quantity must be greater than 0.')
                                else:
                                    qty = im_qty
                            else:
                                error = True
                                mess = mess + _(' Quantity must be data kind of numeric.')
                                
                        if im_price_unit:
                            if isinstance(im_price_unit, float):
                                if im_price_unit < 0:
                                    error = True
                                    mess = mess + _(' Price must be greater than 0.')
                                else:
                                    price_unit = im_price_unit
                            else:
                                error = True
                                mess = mess + _(' Price must be data kind of numeric.')
                        
                        if not error:
                            product = product_id.with_context(lang=this.partner_id.lang, partner=this.partner_id.id,
                                    quantity= qty, date=this.date_order, pricelist=this.pricelist_id.id, uom=product_id.uom_id.id)
                            product_name = product.name_get()[0][1]
                            if product.description_sale:
                                product_name += '\n' + product.description_sale
                            
                            fpos = this.fiscal_position_id or this.partner_id.property_account_position_id
                            taxes_id = fpos.map_tax(product_id.taxes_id.filtered(lambda r: not self.env.user.company_id or r.company_id== self.env.user.company_id))
                    
                            if not product and not im_price_unit:
                                price_unit = 0.0
                            
                            elif product and not im_price_unit:
                                price_unit = self.env['account.tax']._fix_tax_included_price(product.price, product.taxes_id, taxes_id)

                        
                            success += 1 
                            return_lines.append((0,0,{
                                    'product_id': product_id.id,
                                    'name': product_name, 
                                    'product_ean': product_ean,
                                    'price_unit': price_unit,
                                    'product_uom': uom_id,
                                    'product_uom_qty': qty, 
                                    'order_id': this.id}))
                               
                        else:
                            line_errror.append((0,0,{'sale_return_id': this.id, 
                                                     'default_code': default_code or False,
                                                     'product_uom': im_uom,
                                                     'product_qty': im_qty or False,
                                                     'price_unit': im_price_unit or False, 
                                                     'notes': mess}))
                            failure += 1
                            line = row + 1
                            messenger += _('\n - Line ') + _(str(line)) + ':' + _(mess) or ''
                            
            if return_lines != []:
                this.order_line = return_lines
            else:
                this.order_line = False
                
            if line_errror != []:
                this.line_error_ids = line_errror
            else:
                this.line_error_ids = False
                
            this.failure = 0
            if failure > 0:
                this.failure = failure or  0
                warning = _('Errors arising at: ' + messenger)
            this.warning_mess = warning or False
        return True
        
class SaleReturnLine(models.Model):
    _name = 'sale.return.line'
    _order = 'order_id desc, sequence, id'

    @api.depends('product_uom_qty', 'discount', 'price_unit', 'tax_id')
    def _compute_amount(self):
        for line in self:
            price = line.price_unit * (1 - (line.discount or 0.0) / 100.0)
            taxes = line.tax_id.compute_all(price, line.order_id.currency_id, line.product_uom_qty, product=line.product_id, partner=line.order_id.partner_id)
            line.update({
                'price_tax': taxes['total_included'] - taxes['total_excluded'],
                'price_total': taxes['total_included'],
                'price_subtotal': taxes['total_excluded'],
            })
            
    @api.depends('price_subtotal', 'product_uom_qty')
    def _get_price_reduce(self):
        for line in self:
            line.price_reduce = line.price_subtotal / line.product_uom_qty if line.product_uom_qty else 0.0
            
    @api.depends('invoice_lines.move_id.state', 'invoice_lines.quantity')
    def _compute_qty_invoiced(self):
        for line in self:
            qty = 0.0
            for inv_line in line.invoice_lines:
                if inv_line.move_id.state not in ['cancel']:
                    qty += inv_line.product_uom_id._compute_quantity(inv_line.quantity, line.product_uom)
            line.qty_invoiced = qty

    @api.depends('order_id.state', 'move_ids.state')
    def _compute_qty_received(self):
        
        for line in self:
            if line.order_id.state not in ['return', 'done']:
                line.qty_received = 0.0
                continue
            if line.product_id.type not in ['consu', 'product']:
                line.qty_received = line.product_uom_qty
                continue
            
            total = 0.0
            for move in line.move_ids:
                if move.state == 'done':
                    if move.product_uom != line.product_uom:
                        total += move.product_uom._compute_quantity(move.product_uom_qty, line.product_uom, product_id=line.product_id.id)
                    else:
                        total += move.product_uom_qty
            line.qty_received = total
            
    
    def _compute_tax_id(self):
        for line in self:
            fpos = line.order_id.fiscal_position_id or line.order_id.partner_id.property_account_position_id
            if fpos:
                if self.env.uid == SUPERUSER_ID and line.order_id.company_id:
                    taxes = fpos.map_tax(line.product_id.taxes_id).filtered(lambda r: r.company_id == line.order_id.company_id)
                else:
                    taxes = fpos.map_tax(line.product_id.taxes_id)
                line.tax_id = taxes
            else:
                line.tax_id = line.product_id.taxes_id if line.product_id.taxes_id else False
    
    def _currency_price_unit(self):
        for line in self:
            line.currency_price_unit = line.order_id.currency_rate and line.price_unit * line.order_id.currency_rate or line.price_unit
            price = line.price_unit * (1 - (line.discount or 0.0) / 100.0)
            taxes = line.tax_id.compute_all(price, line.order_id.currency_id, line.product_uom_qty, product=line.product_id, partner=line.order_id.partner_id)
            line.currency_price_subtotal = line.order_id.currency_rate and taxes['total_included'] * line.order_id.currency_rate or taxes['total_included']
        
    
    def _price_unit_include(self):
        partner_id = False
        tax_obj = self.pool.get('account.tax')
        cur_obj = self.pool.get('res.currency')
            
        tax_nxk_ids = []
        
        for line in self:
            partner_id = line.order_id.partner_id
            for tax_nxk in line.tax_id:
                if tax_nxk.transaction_type in ('import','export'):
                    tax_nxk_ids.append(tax_nxk.id)
        if tax_nxk_ids:  
            tax_nxk_ids = self.pool.get('account.tax').browse(self.cr,self.uid,tax_nxk_ids)
                
        for line in self:
            price = line.price_unit 
            if tax_nxk_ids:
                taxes = tax_obj.compute_all(self.cr, self.uid, tax_nxk_ids, price, line.product_uom_qty, product=line.product_id, partner=partner_id)
                line.price_unit_include = 0.0
                for tax in taxes['taxes']:
                    line.price_unit_include += tax['amount']
                if line.order_id:
                    cur = line.order_id.currency_id
                    line.price_unit_include = cur_obj.round(self.cr, self.uid, cur, (line.price_unit_include/line.product_uom_qty/line.product_uom_qty) + line.price_unit)
                    line.currency_price_unit_include = line.order_id.currency_rate and line.price_unit_include * line.order_id.currency_rate or line.price_unit_include
            else:
                line.price_unit_include = line.price_unit
                line.currency_price_unit_include = line.order_id.currency_rate and line.price_unit_include * line.order_id.currency_rate or line.price_unit_include
    
            
    order_id = fields.Many2one('sale.return', string='Order Reference',select=True, required=True, ondelete='cascade')
    name = fields.Text(string='Description', required=True)
    sequence = fields.Integer(string='Sequence', default=10)
    
    price_unit = fields.Float('Unit Price', required=True, digits='Product Price', default=0.0)

    price_subtotal = fields.Monetary(compute='_compute_amount', string='Subtotal', readonly=True, store=True)
    price_tax = fields.Monetary(compute='_compute_amount', string='Taxes', readonly=True, store=True)
    price_total = fields.Monetary(compute='_compute_amount', string='Total', readonly=True, store=True)

    price_reduce = fields.Monetary(compute='_get_price_reduce', string='Price Reduce', readonly=True, store=True)
    tax_id = fields.Many2many('account.tax', string='Taxes')

    discount = fields.Float(string='Discount (%)', digits='Discount', default=0.0)
    
    invoice_lines = fields.Many2many('account.move.line', 'sale_return_line_invoice_rel', 'sale_return_line_id', 'invoice_line_id', string='Invoice Lines', copy=False)

    product_id = fields.Many2one('product.product', string='Product', domain=[('sale_ok', '=', True)], change_default=True, ondelete='restrict', required=True)
    product_tmpl_id = fields.Many2one(related='product_id.product_tmpl_id', store=True, string="Product Template")
    
    product_ean = fields.Char(string="Barcode")
    product_uom_qty = fields.Float(string='Quantity', digits='Product Unit of Measure', required=True, default=1.0)
    product_uom = fields.Many2one('uom.uom', string='Unit of Measure', required=True)
    
    qty_invoiced = fields.Float(compute='_compute_qty_invoiced', string="Invoiced Qty", store=True, readonly=True,  default=0.0)
    qty_received = fields.Float(compute='_compute_qty_received', string="Received Qty", store=True, default=0.0)

    currency_id = fields.Many2one(related='order_id.currency_id', store=True, string='Currency', readonly=True)
    company_id = fields.Many2one(related='order_id.company_id', string='Company', store=True, readonly=True)
    order_partner_id = fields.Many2one(related='order_id.partner_id', store=True, string='Customer')
    
    sale_line_id = fields.Many2one('sale.order.line', string='SO Line', copy=False)

    state = fields.Selection([
        ('draft', 'Draft'),
        ('sent', 'RFR Sent'),
        ('approve', 'Approve'),
        ('return','Returns Order'),
        ('done', 'Done'),
        ('cancel', 'Cancelled')
    ], related='order_id.state', string='Order Status', readonly=True, copy=False, store=True, default='draft')

    
    currency_price_unit = fields.Monetary(compute='_currency_price_unit',digits=(16,0),string='Price Unit')
    currency_price_subtotal = fields.Monetary(compute='_currency_price_unit',digits=(16,0),string='Total')
    
    price_unit_include= fields.Monetary(compute='_price_unit_include', string='Price Include')
    currency_price_unit_include = fields.Monetary(compute='_price_unit_include' ,  string='Currency Price Include',)
    
    move_ids = fields.One2many('stock.move', 'sale_return_line_id', string='Reservation', readonly=True, copy=False)
 
    analytic_tag_ids = fields.Many2many(
        'account.analytic.tag', string='Analytic Tags',
        domain="['|', ('company_id', '=', False), ('company_id', '=', company_id)]")
    
    display_type = fields.Selection([
    ('line_section', "Section"),
    ('line_note', "Note")], default=False, help="Technical field for UX purpose.")
    
    qty_to_invoice = fields.Float(
        compute='_get_to_invoice_qty', string='To Invoice Quantity', store=True, readonly=True,
        digits='Product Unit of Measure') 
    
        
    def _get_invoice_line_sequence(self, new=0, old=0):
        return new or old
    
    
    @api.depends('qty_invoiced', 'qty_received', 'product_uom_qty', 'order_id.state')
    def _get_to_invoice_qty(self):
        """
        Compute the quantity to invoice. If the invoice policy is order, the quantity to invoice is
        calculated from the ordered quantity. Otherwise, the quantity delivered is used.
        """
        for line in self:
            if line.order_id.state in ['return', 'done']:
                if line.product_id.invoice_policy == 'order':
                    line.qty_to_invoice = line.product_uom_qty - line.qty_invoiced
                else:
                    line.qty_to_invoice = line.qty_received - line.qty_invoiced
            else:
                line.qty_to_invoice = 0

    
    @api.constrains('product_uom_qty')
    def _check_product_uom_qty(self):
        for line in self:
            if line.product_uom_qty <= 0:
                raise UserError(_('Quantity must be greater than 0.'))
    
      
    @api.constrains('price_unit')
    def _check_price_unit(self):
        for line in self:
            if line.price_unit < 0:
                raise UserError(_('The unit price is not less than 0.'))
    
    @api.onchange('product_id')
    def product_id_change(self):
        if not self.product_id:
            return
        vals = {}
        if not self.product_uom or (self.product_id.uom_id.id != self.product_uom.id):
            vals['product_uom'] = self.product_id.uom_id
            vals['product_uom_qty'] = self.product_uom_qty or 1.0

        product = self.product_id.with_context(
            lang=get_lang(self.env, self.order_id.partner_id.lang).code,
            partner=self.order_id.partner_id,
            quantity=vals.get('product_uom_qty') or self.product_uom_qty,
            date=self.order_id.date_order,
            pricelist=self.order_id.pricelist_id.id,
            uom=self.product_uom.id
        )

        name = product.name_get()[0][1]
        if product.description_sale:
            name += '\n' + product.description_sale
        vals['name'] = name

        self._compute_tax_id()

        if self.order_id.pricelist_id and self.order_id.partner_id:
            vals['price_unit'] = product._get_tax_included_unit_price(
                self.company_id or self.order_id.company_id,
                self.order_id.currency_id,
                self.order_id.date_order,
                'sale',
                fiscal_position=self.order_id.fiscal_position_id,
                product_price_unit=self._get_display_price(product),
                product_currency=self.order_id.currency_id
            )
        self.update(vals)

        title = False
        message = False
        result = {}
        warning = {}
        if product.sale_line_warn != 'no-message':
            title = _("Warning for %s") % product.name
            message = product.sale_line_warn_msg
            warning['title'] = title
            warning['message'] = message
            result = {'warning': warning}
            if product.sale_line_warn == 'block':
                self.product_id = False

        return result
    
    
    def _get_display_price(self, product):
            # TO DO: move me in master/saas-16 on sale.order
        # awa: don't know if it's still the case since we need the "product_no_variant_attribute_value_ids" field now
        # to be able to compute the full price

        # it is possible that a no_variant attribute is still in a variant if
        # the type of the attribute has been changed after creation.
        # no_variant_attributes_price_extra = [
        #     ptav.price_extra for ptav in self.product_no_variant_attribute_value_ids.filtered(
        #         lambda ptav:
        #             ptav.price_extra and
        #             ptav not in product.product_template_attribute_value_ids
        #     )
        # ]
        # if no_variant_attributes_price_extra:
        #     product = product.with_context(
        #         no_variant_attributes_price_extra=tuple(no_variant_attributes_price_extra)
        #     )

        if self.order_id.pricelist_id.discount_policy == 'with_discount':
            return product.with_context(pricelist=self.order_id.pricelist_id.id, uom=self.product_uom.id).price
        product_context = dict(self.env.context, partner_id=self.order_id.partner_id.id, date=self.order_id.date_order, uom=self.product_uom.id)

        final_price, rule_id = self.order_id.pricelist_id.with_context(product_context).get_product_price_rule(product or self.product_id, self.product_uom_qty or 1.0, self.order_id.partner_id)
        base_price, currency = self.with_context(product_context)._get_real_price_currency(product, rule_id, self.product_uom_qty, self.product_uom, self.order_id.pricelist_id.id)
        if currency != self.order_id.pricelist_id.currency_id:
            base_price = currency._convert(
                base_price, self.order_id.pricelist_id.currency_id,
                self.order_id.company_id or self.env.company, self.order_id.date_order or fields.Date.today())
        # negative discounts (= surcharge) are included in the display price
        return max(base_price, final_price)
    
        
        
        
    @api.model
    def get_price_product_with_pricelist(self,price,product,order,product_uom_qty,product_uom):
        product_id = product.with_context(
                lang=order.partner_id.lang,
                partner=order.partner_id.id,
                quantity=product_uom_qty,
                date_order=order.date_order,
                pricelist=price.id,
                uom=product_uom.id,
                fiscal_position=self.env.context.get('fiscal_position')
            )
        return product_id
    
    @api.onchange('product_uom', 'product_uom_qty')
    def product_uom_change(self):
        if not self.product_uom or not self.product_id:
            self.price_unit = 0.0
            return
        if self.order_id.pricelist_id and self.order_id.partner_id:
            product = self.product_id.with_context(
                lang=self.order_id.partner_id.lang,
                partner=self.order_id.partner_id,
                quantity=self.product_uom_qty,
                date=self.order_id.date_order,
                pricelist=self.order_id.pricelist_id.id,
                uom=self.product_uom.id,
                fiscal_position=self.env.context.get('fiscal_position')
            )
            self.price_unit = product._get_tax_included_unit_price(
                self.company_id or self.order_id.company_id,
                self.order_id.currency_id,
                self.order_id.date_order,
                'sale',
                fiscal_position=self.order_id.fiscal_position_id,
                product_price_unit=self._get_display_price(product),
                product_currency=self.order_id.currency_id
            )
    
    def _create_stock_moves(self, picking):
        moves = self.env['stock.move']
        done = self.env['stock.move'].browse()
        for line in self:
            order = line.order_id
            price_unit = 0
            if line.sale_line_id:
                moves_id = moves.search([('sale_line_id','=',line.sale_line_id.id),('state','=','done')], order='date DESC',limit=1) or False
                price_unit = moves_id and moves_id.price_unit or 0
            if not price_unit:
                moves_id = moves.search([('product_id','=',line.product_id.id),('location_id.usage','=','supplier'),('location_dest_id.usage','=','internal'),('state','=','done')], order='date DESC',limit=1) or False
                price_unit = moves_id and moves_id.price_unit or 0
            
#             if line.tax_id:
#                 price_unit = line.tax_id.compute_all(price_unit, currency=line.order_id.currency_id, quantity=1.0)['total_excluded']
#             if line.product_uom.id != line.product_id.uom_id.id:
#                 price_unit *= line.product_uom.factor / line.product_id.uom_id.factor
#             if order.currency_id != order.company_id.currency_id:
#                 price_unit = order.currency_id.compute(price_unit, order.company_id.currency_id, round=False)

            template = {
                'name': line.name or '',
                'product_id': line.product_id.id,
                'product_uom': line.product_uom.id,
                'product_uom_qty': line.product_uom_qty, 
                'date': picking.date,
                'date_expected': picking.scheduled_date or line.order_id.validity_date,
                'location_id': picking.location_id.id,
                'location_dest_id': picking.location_dest_id.id or False,
                'picking_id': picking.id,
                'partner_id': picking.partner_id.id, 
                'move_dest_ids': False,
                'state': 'draft',
                'sale_return_line_id': line.id,
                'company_id': picking.company_id.id,
                'price_unit': price_unit,
                'picking_type_id': picking.picking_type_id.id or self.order_id.picking_type_id.id,
                'group_id': False,
                'origin': line.order_id.name,
                'route_ids': [],
                'warehouse_id': line.order_id.warehouse_id.id,
                'show_operations': False
                    }
            done += moves.create(template)
        return done
    
class SaleOrder(models.Model):
    _inherit = "sale.order"
    
    @api.depends('order_line.sale_return_line_ids.order_id.state')
    def _compute_return(self):
        for order in self:
            returns = self.env['sale.return']
            for line in order.order_line:
                rline = line.sale_return_line_ids.filtered(lambda r: r.state != 'cancel')
                returns |= rline.mapped('order_id')
            order.return_count = len(returns)
            order.return_ids = returns
            
    return_count = fields.Integer(string='# of Returns', compute='_compute_return', readonly=True, store=True)
    return_ids = fields.Many2many('sale.return', compute='_compute_return', string='Receptions', copy=False, store=True)
            
    
    def action_cancel(self):
        for order in self:
            if any(order.return_ids.filtered(lambda x: x.state in ('approve','return','done'))):
                raise UserError(_('Unable to cancel Sale Order %s because this order has some return order.') % (order.name))
        return super(SaleOrder, self).action_cancel()
    
    
    def action_wizard_sale_return(self):
        if not any(self.order_line.filtered(lambda x: x.qty_delivered > 0)) and not self.return_count:
            raise UserError(_('Not defined product delivered.'))
        action = self.env.ref('sale_return.action_view_wizard_sale_return')
        result = action.read()[0]
        result['context'] = {'active_id': self.id}
        return result
    
    def create_invoice_line(self, invoice_new_id, journal_id):
        if not invoice_new_id or not journal_id:
            return 
        
        vals = {}
        invoice_line = self.env['account.move.line']
        for line in self.order_line:
            if line.product_id.invoice_policy == 'order':
                qty = line.product_uom_qty - line.qty_return - line.qty_invoiced
            elif line.product_id.invoice_policy == 'delivery':
                qty = line.qty_delivered - line.qty_return - line.qty_invoiced
            if float_compare(qty, 0.0, precision_rounding=line.product_uom.rounding) <= 0:
                qty = 0.0
            if qty == 0:
                continue
            
            taxes = line.tax_id or line.product_id.taxes_id
            invoice_line_tax_ids = self.fiscal_position_id.map_tax(taxes)
            
            account = invoice_line.get_invoice_line_account('in_invoice', line.product_id, self.fiscal_position_id, self.env.user.company_id)
            if account:
                account_id = account.id
            
            vals = {
                'move_id':invoice_new_id.id,
                'sale_line_id': line.id,
                'name': line.name,
                'origin': self.name,
                'uom_id': line.product_uom.id,
                'product_id': line.product_id.id,
                'account_id': self.env['account.move.line'].with_context({'journal_id': journal_id, 'type': 'in_invoice'})._default_account(),
                'price_unit': line.order_id.currency_id.compute(line.price_unit, self.currency_id, round=False),
                'quantity': 0,
                'discount': 0.0,
                'account_analytic_id': line.account_analytic_id.id,
                'invoice_line_tax_ids': [(6,0, invoice_line_tax_ids.ids)],
                'account_id': account_id or False
                }
            invoice_line.create(vals)
            
class SaleOrderLine(models.Model):
    _inherit = "sale.order.line"
    
    
    @api.depends('sale_return_line_ids.move_ids.state')
    def _get_qty_return(self):
        for line in self:
            if not line.sale_return_line_ids:
                return
            # line = sale order line
            # re = sale return line
            # move = move_id link to
            qty_return = 0.0
            for re in line.sale_return_line_ids.filtered(lambda r: r.state in ('approve','return','done')):
                for move in re.move_ids.filtered(lambda r: r.state == 'done'):
                        qty_return += re.product_uom_qty
            line.qty_return = qty_return
            
    @api.depends('qty_delivered','sale_return_line_ids.state')
    def _get_remaining_qty(self):
        productuom = self.env['uom.uom']
        for line in self:
            returned_qty = 0.0
            for re in line.sale_return_line_ids.filtered(lambda r: r.state in ('approve','return','done')):
                if re.product_uom != line.product_uom:
                    returned_qty += productuom._compute_quantity(re.product_uom, re.product_uom_qty, line.product_uom, True, 'UP', True)
                else:
                    returned_qty += re.product_uom_qty
            line.remaining_qty = line.qty_delivered - returned_qty or 0
        
    qty_return = fields.Float(compute='_get_qty_return', string='Returned Qty', default=0, readonly=True, store=True)
    remaining_qty = fields.Float(compute='_get_remaining_qty', string='Remaining Quantity', default=0, readonly=True, store=True)
    
    sale_return_line_ids = fields.One2many('sale.return.line', 'sale_line_id', string='Return Lines', copy=False) 

class StockPicking(models.Model):
    _inherit = "stock.picking"
    
    # sale_return_id = fields.Many2one(related='move_lines.sale_return_line_id.order_id', string="Sale Return Orders",readonly=True)

    
    def action_revert_done(self):
#         for pick in self:
#             if pick.sale_id.state == 'done':
#                 raise UserError(_("Can't reopen a picking when relative sale order is done!"))
        return super(StockPicking, self).action_revert_done()
    
class AccountInvoiceLine(models.Model):
    _inherit = 'account.move.line'
    
    sale_return_line_ids = fields.Many2many('sale.return.line', 'sale_return_line_invoice_rel', 
        'invoice_line_id', 'sale_return_line_id',string='Return Order Lines', readonly=True, copy=False)       
    
class MailComposeMessage(models.TransientModel):
    _inherit = 'mail.compose.message'

    
    def send_mail(self, auto_commit=False):
        if self._context.get('default_model') == 'sale.return' and self._context.get('default_res_id') and self._context.get('mark_so_as_sent'):
            order = self.env['sale.return'].browse([self._context['default_res_id']])
            if order.state == 'draft':
                order.state = 'sent'
        return super(MailComposeMessage, self.with_context(mail_post_autofollow=True)).send_mail(auto_commit=auto_commit)

class AccountInvoice(models.Model):
    _inherit="account.move"
    
    @api.model
    def create(self,vals):
        context = self._context or {}
        if context.get('ctx_no_create'):
            raise UserError(_('You do not create new this document. Please contact the Administrator!!!'))
        return super(AccountInvoice, self).create(vals)
    
# class ImportError(models.Model):
#     _name = "errror.import"
    
#     sale_return_id = fields.Many2one('sale.return', 'Sale Return', ondelete='cascade')
