# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import api, fields, models, _
from odoo.tools.translate import _
from odoo.exceptions import UserError

class StockPicking(models.Model):
    _inherit = "stock.picking"
    
    @api.depends('move_lines')
    def _compute_sale_return_id(self):
        for picking in self:
            sale_return = False
            for move in picking.move_lines.filtered(lambda x: x.sale_return_line_id):
                sale_return = move.sale_return_line_id.order_id
                break
            picking.sale_return_id = sale_return.id if sale_return else False

    def _search_sale_return_id(self, operator, value):
        moves = self.env['stock.move'].search(
            [('picking_id', '!=', False), ('sale_return_line_id.order_id', operator, value)]
        )
        return [('id', 'in', moves.mapped('picking_id').ids)]
    
    sale_return_id = fields.Many2one(comodel_name='sale.return', string="Sale Return Order",
                              compute='_compute_sale_return_id', search='_search_sale_return_id', store=True)

    def action_revert_done(self):
#         for pick in self:
#             if pick.sale_return_id.state == 'done':
#                 raise UserError(_("Can't reopen a picking when relative sale order return is done!"))
        return super(StockPicking, self).action_revert_done()
    
class StockMove(models.Model):
    _inherit = 'stock.move'
    
    sale_return_line_id = fields.Many2one('sale.return.line','Sale Return Line', ondelete='set null', select=True,readonly=True)
    
    
    def force_assign(self):
        """ Changes the state to assigned.
        @return: True
        """
        self.ensure_one()
        res = self.write({'state': 'waiting'})
        # self.check_recompute_pack_op()
        return res
    
    
    def get_price_unit(self, cr, uid, move, context=None):
        res = super(StockMove, self).get_price_unit(cr, uid, move, context=context)
        if move.sale_return_line_id:
            return move.price_unit
        return res
    
    def copy(self, default=None):
        if not default.get('split_from'):
            default['sale_return_line_id'] = False
        return super(StockMove, self).copy(default)