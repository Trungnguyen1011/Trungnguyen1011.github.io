# -*- coding: utf-8 -*-

import time
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT
from odoo import api, fields, models, _
from odoo.exceptions import UserError

class WizardSaleReturn(models.TransientModel):
    _name = "wizard.sale.return"
    
    user_id = fields.Many2one('res.users', string="Responsible")
    sale_id = fields.Many2one('sale.order', string="Sales Order")
    
    date_create = fields.Datetime('Date')
    date_planned = fields.Datetime(string='Scheduled Date')
    
    wizard_line = fields.One2many('wizard.sale.return.line','wizard_id',string="Request Line")
    
    warehouse_id = fields.Many2one('stock.warehouse', string = "Warehouse")
    
    @api.model
    def default_get(self, fields):
        res = {}
        var = []
        sale_obj = self.env['sale.order']
        active_id = self._context.get('active_id')  
        if active_id:
            sale = sale_obj.browse(active_id)
            res = {'sale_id': sale.id, 
                   'user_id': self.env.user.id, 
                   'warehouse_id': sale.warehouse_id.id,
                   'date_create': time.strftime(DEFAULT_SERVER_DATETIME_FORMAT),
                   'date_planned': time.strftime(DEFAULT_SERVER_DATETIME_FORMAT)}
            for line in sale.order_line.filtered(lambda x: x.qty_delivered > 0):
#                 taxes = line.tax_id.compute_all(line.price_unit, sale.currency_id, line.remaining_qty, product=line.product_id, partner=sale.partner_id)
#                 price_subtotal = taxes['total_excluded'] or 0.0
                var.append((0, 0,{'name': line.name, 
                                   'product_id':line.product_id.id, 
                                   'product_ean': line.product_id.barcode,
                                   'price_unit': line.price_unit, 
                                   'discount': line.discount,
#                                    'price_subtotal': price_subtotal,
                                   'product_uom': line.product_uom.id,
                                   'product_qty': line.remaining_qty,
                                   'max_qty': line.remaining_qty,
                                   'tax_id': [(6, 0, [x.id for x in line.tax_id])] or False,
                                   'sale_line_id': line.id}))
            res.update({'wizard_line':var})
        return res
    

    def action_view_return(self):
        context = self._context
        if context.get('active_model') == 'sale.order' and context.get('active_ids'):
            sale = self.env['sale.order'].browse(context['active_ids'])[0]
            action = self.env.ref('sale_return.action_sale_return_rfr')
            result = action.read()[0]
            result['context'] = {}
            
            if not len(sale.return_ids):
                self.action_create_return()
            
            if len(sale.return_ids) != 1:
                result['domain'] = "[('id', 'in', " + str(sale.return_ids.ids) + ")]"
            elif len(sale.return_ids) == 1:
                res = self.env.ref('sale_return.view_sale_return_order_form', False)
                result['views'] = [(res and res.id or False, 'form')]
                result['res_id'] = sale.return_ids.id
            else:
                result = {'type': 'ir.actions.act_window_close'}
            return result
    
    
    def action_create_return(self):
        res = self._prepare_return()
        sreturn = self.env['sale.return'].create(res)
        self._prepare_return_line(sreturn)
        sreturn.button_confirm()
        
        imd = self.env['ir.model.data']
        action = self.env.ref('sale_return.action_sale_return_rfr')
        form_view_id = imd.xmlid_to_res_id('sale_return.view_sale_return_order_form')
        result = action.read()[0]
        result['views'] = [(form_view_id, 'form')]
        result['res_id'] = sreturn.id
        
        return result
    
    @api.model
    def _prepare_return(self):
        return {
                'team_id':self.sale_id.team_id.id,
                'name': 'New',
                'user_id': self.sale_id.user_id.id, 
                'validity_date': self.date_planned,
                'partner_id': self.sale_id.partner_id.id,
                'pricelist_id': self.sale_id.pricelist_id.id,
                'client_order_ref':self.sale_id.client_order_ref,
                'currency_id': self.sale_id.currency_id.id, 
                'currency_rate': self.sale_id.currency_rate,
                'warehouse_id': self.warehouse_id.id, 
                'origin': self.sale_id.name,
                'picking_type_id': self.sale_id.warehouse_id.pick_type_id.id, 
                'company_id': self.sale_id.company_id.id
                }
        
     
    def _prepare_return_line(self, sreturn):
        context = self._context
        if context.get('active_model') == 'sale.order' and context.get('active_ids'):
            sale = self.env['sale.order'].browse(context['active_ids'])[0]
            # name = line.name
            # product_id = line.product_id.id
        ptline = self.env['sale.return.line']
        
        for line in self.wizard_line:
            taxes = line.product_id.taxes_id
            fpos = self.sale_id.partner_id.property_account_position_id
            if fpos:
                tax_id = fpos.map_tax(taxes).ids if fpos else []
            else:
                tax_id = [x.id for x in taxes]
            
            ptline.create({
                'product_id': line.sale_line_id.product_id.id,
                'product_ean': line.sale_line_id.product_id.barcode,
                'name': line.sale_line_id.name, 
                'product_uom_qty': line.product_qty, 
                'product_uom': line.sale_line_id.product_uom.id,
                'price_unit': line.price_unit,
                'sale_line_id': line.sale_line_id.id,
                'order_id': sreturn.id,
                'tax_id': [(6, 0, tax_id)],
                'discount': line.discount,
                        })
        return True
        
class WizardSaleReturnLine(models.TransientModel):
    _name = "wizard.sale.return.line"
    
#     @api.depends('product_qty', 'price_unit', 'tax_id')
#     def _compute_amount(self):
#         for line in self:
#             taxes = line.tax_id.compute_all(line.price_unit, line.wizard_id.sale_id.currency_id, line.product_qty, product=line.product_id, partner=line.wizard_id.sale_id.partner_id)
#             line.update({
#                 'price_subtotal': taxes['total_excluded'],
#                         })
    
    seq = fields.Integer('Seq', default=10)
    
    name = fields.Text('Description', readonly=True)
    product_id = fields.Many2one('product.product', string='Product', readonly=True)
    product_ean = fields.Char(string="Barcode")    
    product_uom = fields.Many2one('product.uom', string='UoM')
    product_qty = fields.Float('Qty', default=1.0)
    max_qty = fields.Float('Max Qty', default=1.0)
    discount = fields.Float(string='Discount (%)', digits='Discount', default=0.0)
    
    price_unit = fields.Float('Price Unit', default=1.0)
    tax_id = fields.Many2many('account.tax', string='Taxes')
    
#     price_subtotal = fields.Float(compute='_compute_amount', string='Subtotal', store=True)
    
    wizard_id = fields.Many2one('wizard.sale.return', 'Wizard', ondelete='cascade')
    sale_line_id = fields.Many2one('sale.order.line', string='SO Line')
    
    @api.onchange('product_qty', 'product_uom')
    def _onchange_product_qty(self):
        for line in self:
            if line.product_qty > line.max_qty:
                raise UserError('Cant return more than qty_invoiced')
    
#     @api.onchange('product_qty', 'product_uom')
#     def _onchange_product_id_check_availability(self):
#         if not self.product_id or not self.product_qty or not self.product_uom:
#             return {}
#         if self.product_id.type == 'product':
#             precision = self.env['decimal.precision'].precision_get('Product Unit of Measure')
#             product_qty = self.env['product.uom']._compute_qty_obj(self.product_uom, self.product_qty, self.product_id.uom_id, product_id=self.product_id.id) or 0.0
#             product_onhand = self.env['product.product'].get_Product_Onhand(self.product_id.id, self.wizard_id.sale_id.warehouse_id.lot_stock_id.id, False) or 0.0
#             if product_onhand < product_qty:
#                 warning_mess = {'title': _('Not enough inventory!!'),
#                     'message' : _('''You plan to sell %.2f %s but you only have %.2f %s available!\nThe stock on hand is %.2f %s..''')
#                     %(self.product_qty, self.product_uom.name,product_onhand,self.product_id.uom_id.name, product_onhand,self.product_id.uom_id.name)}
#                 return {'warning': warning_mess}
#         return {}
    