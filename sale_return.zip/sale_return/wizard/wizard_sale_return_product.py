# -*- coding: utf-8 -*-

import time
from datetime import datetime
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT
from odoo import api, fields, models, _
from odoo.exceptions import UserError

class WizardSaleReturnProduct(models.TransientModel):
    _name = "wizard.sale.return.product"
    
    sale_return_id = fields.Many2one('sale.return',string="Sale Return")
    company_id = fields.Many2one('res.company', 'Company')
    
    product_tmpl_id = fields.Many2one('product.template', string="Product Template", domain=[('sale_ok', '=', True)])
    category_id = fields.Many2one('product.category', string="Category") 
 
    wizard_line_ids = fields.One2many('wizard.sale.return.product.line', 'wizard_id', string="Wizard Line")
    
    
    @api.model 
    def default_get(self, default_fields):
        res = super(WizardSaleReturnProduct, self).default_get(default_fields)
        if self._context.get('active_id'):
            sale_return = self.env['sale.return'].browse(self._context.get('active_id'))
            res = {'sale_return_id': sale_return.id, 'company_id': sale_return.company_id.id}
        return res
    
    @api.onchange('category_id')
    def onchange_category_id(self):
        if not self.category_id:
            return {'domain': {'product_tmpl_id': []}}
        return {'domain': {'product_tmpl_id': [('categ_id','child_of',self.category_id.id)]}}
    
    @api.onchange('product_tmpl_id')
    def onchange_search_product(self):
        if not self.product_tmpl_id:
            return
        
        vars = []
        for prod in self.product_tmpl_id.product_variant_ids:
            product = prod.with_context(lang=self.sale_return_id.partner_id.lang, partner=self.sale_return_id.partner_id.id,
                quantity=1, date=self.sale_return_id.create_date, pricelist=self.sale_return_id.pricelist_id.id, uom=prod.uom_id.id)
            name = product.name_get()[0][1]
            if product.description_sale:
                name += '\n' + product.description_sale
            
            fpos = self.sale_return_id.fiscal_position_id or self.sale_return_id.partner_id.property_account_position_id
            taxes = prod.taxes_id.filtered(lambda r: not self.company_id or r.company_id == self.company_id)
            tax_id = fpos.map_tax(taxes) if fpos else taxes
            
            price_unit = self.env['account.tax']._fix_tax_included_price(prod.price or prod.lst_price, prod.taxes_id, tax_id)
            vars.append((0, 0,{
                'product_id': prod.id,
                'name': name,
                'product_ean': prod.barcode,
                'product_uom_qty': 0,
                'price_unit': price_unit,
                'product_uom': prod.uom_id.id,
                'tax_id': tax_id,
                   }))
        self.wizard_line_ids = vars
        
    def save(self):
        for line in self.wizard_line_ids.filtered(lambda x: x.product_uom_qty > 0):
            self.sale_return_id.order_line += self.sale_return_id.order_line.new({
                'product_id': line.product_id.id,
                'product_ean': line.product_ean,
                'name': line.name, 
                'product_uom_qty': line.product_uom_qty, 
                'product_uom': line.product_uom.id,
                'price_unit': line.price_unit,
                'order_id': self.sale_return_id.id,
                'tax_id': [(6, 0, line.tax_id.ids)]})
        return {}
        
    def save_new(self):
        self.save()
        action = self.env.ref('sale_return.action_wizard_sale_return_product')
        result = action.read()[0]
        result['context'] = {'active_id': self.sale_return_id.id}
        return result
        
    
class WizardSaleReturnProductLine(models.TransientModel):
    _name = "wizard.sale.return.product.line"
    
    sequence = fields.Integer('Sequence', default=10)
    name = fields.Char(string="Description")
    
    product_id = fields.Many2one('product.product', string='Product', domain=[('sale_ok', '=', True)])
    product_ean = fields.Char(string="Barcode")
    
    product_uom_qty = fields.Float(string='Qty', digits='Product Unit of Measure', default=1.0)
    product_uom = fields.Many2one('product.uom', string="UoM")
    
    price_unit = fields.Float(string='Price Unit', digits='Product Price', default=0.0)
    tax_id = fields.Many2many('account.tax', string='Taxes', domain=['|', ('active', '=', False), ('active', '=', True)])
    
    wizard_id = fields.Many2one('wizard.sale.return.product', sting="Wizard", ondelete='cascade')
    
    
    @api.onchange('product_ean')
    def onchange_product_ean(self):
        uom_relation = self.env['product.product']
        if not self.product_ean:
            return 
        
        uom_relation_ids = uom_relation.search([('barcode','=',self.product_ean),('id','=',self.product_id.id),('active','=',True)], limit=1) or []
        if len(uom_relation_ids):
            self.product_uom = uom_relation_ids.uom_id.id or False
        else:
            raise UserError(_("Barcode %s is not exist!")%(self.product_ean))
        return {}
        
    @api.onchange('product_uom', 'product_uom_qty')
    def product_uom_change(self):
        uom_relation = self.env['product.product']
        if not self.product_uom:
            self.price_unit = 0.0
            return
        if self.wizard_id.sale_return_id.pricelist_id and self.wizard_id.sale_return_id.partner_id:
            product = self.product_id.with_context(
                lang=self.wizard_id.sale_return_id.partner_id.lang,
                partner=self.wizard_id.sale_return_id.partner_id.id,
                quantity=self.product_uom_qty,
                date_order=self.wizard_id.sale_return_id.create_date,
                pricelist=self.wizard_id.sale_return_id.pricelist_id.id,
                uom=self.product_uom.id,
                fiscal_position=self.env.context.get('fiscal_position')
            )
            self.price_unit = self.env['account.tax']._fix_tax_included_price(product.price, product.taxes_id, self.tax_id)
        if self.product_id:
            uom_relation_ids = uom_relation.search([('id','=',self.product_id.id),('uom_id','=',self.product_uom.id),('active','=',True)], limit=1) or []
            if len(uom_relation_ids):
                self.with_context(ctx_nochange=True).product_ean = uom_relation_ids.barcode
        return {}
            
    